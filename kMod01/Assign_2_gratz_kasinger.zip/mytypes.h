#ifndef MYTYPES_H_
#define MYTYPES_H_

typedef char str[256]; /* "feature" strings */


#endif /*MYTYPES_H_*/
