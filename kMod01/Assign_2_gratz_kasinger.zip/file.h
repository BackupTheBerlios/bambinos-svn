#ifndef DATFILEHANDLING_H_
#define DATFILEHANDLING_H_

FILE *	foread(str path);

FILE * 	fowrite(str path);

#endif /*DATFILEHANDLING_H_*/
